Moją maszyną kliencką jest własny system, kontem guest - moje własne konto na nim.
Serwer to maszyna wirtualna z laboratorium z serwerem ssh wystawionym na porcie 31337.
Zakładam, że istnieje konto U na obu systemach.

Na koncie guest należy wykonać skrypt guest.sh, na koncie U (na maszynie klienckiej) - U.sh . Następnie należy wykonać skrypt rootS.sh jako root na serwerze.
