#! /bin/sh
# wykonac jako root na serwerze (na koncu)

cp /home/U/sshd_config /etc/ssh/
service ssh restart

